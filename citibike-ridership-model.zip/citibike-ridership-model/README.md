# Citibike Ridership Model

Predicting daily NYC Citi Bike ridership using historical trip data and weather observations.

## Folder structure
- `code/` — Jupyter notebooks for EDA, preprocessing, and modeling
- `data/` — exported CSV datasets
- `queries/` — SQL queries used to build the dataset
- `docs/` — data dictionary and supporting notes
